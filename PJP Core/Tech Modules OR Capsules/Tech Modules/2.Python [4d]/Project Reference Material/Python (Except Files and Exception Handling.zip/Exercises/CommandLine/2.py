import sys

n = len(sys.argv)
st = ""

for i in range(1,n):
    st = sys.argv[i]
    print(st, end = " ")