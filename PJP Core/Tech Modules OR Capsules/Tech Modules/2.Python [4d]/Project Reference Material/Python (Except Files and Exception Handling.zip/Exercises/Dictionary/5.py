Mydict2 = {}

for i in range(1, 15+1):
    key = i
    value = i * i
    Mydict2[key] = value
    
print(Mydict2)