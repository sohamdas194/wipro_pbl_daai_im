dic = {1:10, 2:20, 3:30}

sum  = 0

for i in dic:
    sum = sum + dic[i]
    
print ("The sum of dictionary values:", sum)