def add(list1):
    s = 0
    for i in list1:
        s = s+i

    return s

list2 = [8, 2, 3, 0, 7]

so = add(list2)

print(so)