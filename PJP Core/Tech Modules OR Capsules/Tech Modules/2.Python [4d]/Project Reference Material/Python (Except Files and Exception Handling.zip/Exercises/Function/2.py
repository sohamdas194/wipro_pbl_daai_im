def reverse(str1):
    rev = str1[::-1]
    return rev

str2 = "test123"

print(reverse(str2))