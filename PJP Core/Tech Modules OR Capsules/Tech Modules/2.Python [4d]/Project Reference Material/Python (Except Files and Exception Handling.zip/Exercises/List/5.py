MyList1 = [10,20,10,40,50,60]
MyList2 = [11, 21]
MyList2.extend(MyList1)
print(MyList2)

# MyList1 = [10,20,30,40,50,60]
# MyList2 = [11, 21]
# List3 = MyList2 + MyList1
# print(List3)

# MyList1 = [10,20,30,40,50,60]
# MyList2 = [11, 21]
# MyList2.reverse()
# for i in MyList2:
#     MyList1.insert(0,i)
    
# print(MyList1)