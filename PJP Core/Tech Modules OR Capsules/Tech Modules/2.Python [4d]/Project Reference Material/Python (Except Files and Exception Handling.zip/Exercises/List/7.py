MyList1 = [10,20,10,40,50,60]
print(MyList1)
print()
n = int(input("Enter the index to be removed: "))
MyList1.pop(n)
print()
print(MyList1)
