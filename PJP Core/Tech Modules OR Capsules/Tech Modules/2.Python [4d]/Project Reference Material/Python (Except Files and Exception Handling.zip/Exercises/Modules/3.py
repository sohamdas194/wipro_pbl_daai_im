import math

num = int(input("Enter a number:"))

print("Square root:", math.sqrt(num))