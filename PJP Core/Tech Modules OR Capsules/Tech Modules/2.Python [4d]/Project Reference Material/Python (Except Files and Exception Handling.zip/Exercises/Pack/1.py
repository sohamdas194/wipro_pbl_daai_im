import math.math_module as m
a = int(input("Enter number 1: "))
b = int(input("Enter number 2: "))

print("Mathematical operations: ")
print()
print()

s = m.add(a, b)
d = m.sub(a, b)
mu = m.mul(a, b)
di = m.div(a, b)

print("Sum is:", s)
print("Subtraction:", d)
print("Multiplication:", mu)
print("Division:", di)

