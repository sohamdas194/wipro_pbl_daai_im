set1 = {1, 2, 3, 4}

print(set1)
print()
ele = int(input("Enter the element to be removed: "))

set1.remove(ele)

print(set1)