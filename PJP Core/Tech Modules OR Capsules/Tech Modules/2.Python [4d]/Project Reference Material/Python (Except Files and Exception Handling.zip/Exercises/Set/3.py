set1 = {1, 2, 3, 4}
set2 = {3, 4, 5, 6}

print("Set 1: ", set1)
print("Set 2: ", set2)

set3 = set1.union(set2)

print("Union of set 1 and set 2: ", set3)