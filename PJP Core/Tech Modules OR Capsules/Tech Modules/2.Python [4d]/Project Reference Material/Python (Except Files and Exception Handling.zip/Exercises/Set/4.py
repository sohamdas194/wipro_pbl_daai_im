set1 = {14, 23, 5, 235}

print("Maximum element in a set: ", max(set1))
print("Minimum element in a set: ", min(set1))