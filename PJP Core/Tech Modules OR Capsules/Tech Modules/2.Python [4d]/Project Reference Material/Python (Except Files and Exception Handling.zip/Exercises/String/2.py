
st = "Malayalam"
stlo = st.lower()

strev = stlo[::-1]

if(strev == stlo):
    print ("It's a palindrome")
else:
    print("It's not a palindrome")