st = input("Enter a string more than 2 characters: ")

ch = st[0:2]

le = len(st)

for i in range(0, le):
    print(ch, end="")